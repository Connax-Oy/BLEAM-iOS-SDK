//
//  BLEAM.h
//  BLEAM
//
//  Created by Aleksei Zaikin on 16.01.2020.
//  Copyright © 2020 Connax Oy. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double BLEAMVersionNumber;
FOUNDATION_EXPORT const unsigned char BLEAMVersionString[];
